package com.example.springBootAppByWDarawsheh.Service;

import com.example.springBootAppByWDarawsheh.Model.SupplyDocument;
import com.example.springBootAppByWDarawsheh.Model.WarehouseResponse;
import com.example.springBootAppByWDarawsheh.Repository.SupplyDocumentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.util.List;
import java.util.Optional;

@Service
public class SupplyDocumentService {
//    @Autowired
//    private SupplyDocumentRepository;
//
//    @Transactional
//    public List<SupplyDocument> getSupplyDocument(Integer sCreatedBy) {
//        try {
//            return supplyDocumentRepository.returnSupplyDocuments(sCreatedBy);
//        } catch (Exception e) {
//            // Log the exception (optional)
//            System.out.println("An error occurred during login: " + e.getMessage());
//            return null; // or handle the exception as needed
//        }
//    }
//
//    public WarehouseResponse InsertSupplyDocument(String sName, String sSubject, Integer sCreatedBy, Integer sitemID) {
//        try {
//            Integer generatedId =  supplyDocumentRepository.insertSupplyDocument(sName, sSubject, sCreatedBy, sitemID);
//            return new WarehouseResponse(generatedId);
//
//        } catch (Exception e) {
//            System.out.println("An error occurred during login: " + e.getMessage());
//            return null; // or handle the exception as needed
//        }
//    }
//
//    public Integer deleteSupplyDocument(String sId) {
//        return supplyDocumentRepository.deleteSupplyDocument(sId);
//    }
private SupplyDocumentRepository supplyDocumentRepository;

    public SupplyDocument addDocument(SupplyDocument document) {
        document.setStatus("pending");
        return supplyDocumentRepository.save(document);
    }

    public List<SupplyDocument> getDocumentsByUser(String createdBy) {
        return supplyDocumentRepository.findByCreatedBy(createdBy);
    }

    public List<SupplyDocument> getAllDocuments() {
        return supplyDocumentRepository.findAll();
    }

    public void deleteDocument(Integer id) {
        supplyDocumentRepository.deleteById(id);
    }

    public SupplyDocument updateDocumentStatus(Integer id, String status) {
        Optional<SupplyDocument> optionalDocument = supplyDocumentRepository.findById(id);
        if (optionalDocument.isPresent()) {
            SupplyDocument document = optionalDocument.get();
            document.setStatus(status);
            return supplyDocumentRepository.save(document);
        }
        return null;
    }
}
}
