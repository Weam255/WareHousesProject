package com.example.springBootAppByWDarawsheh.Model;

public class WarehouseResponse {
    private Integer id;

    public WarehouseResponse(Integer id) {
        this.id = id;
    }

    public WarehouseResponse(String failedToAddTheWarehouse) {
    }

    // Getter and Setter
    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }
}
