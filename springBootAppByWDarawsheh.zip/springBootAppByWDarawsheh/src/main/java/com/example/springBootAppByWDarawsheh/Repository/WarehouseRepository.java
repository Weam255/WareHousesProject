package com.example.springBootAppByWDarawsheh.Repository;

import com.example.springBootAppByWDarawsheh.Model.Warehouse;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.query.Procedure;
import org.springframework.data.repository.query.Param;

import java.util.List;

// WarehouseRepository.java
public interface WarehouseRepository extends JpaRepository<Warehouse, Integer> {

    @Procedure(name = "InsertWarehouse")
    int insertWarehouse(
            @Param("warehouse_name") String name,
            @Param("warehouse_description") String description,
            @Param("created_by") String createdBy
    );

    @Procedure(name = "ReturnWarehouses")
    List<Warehouse> returnWarehouses(
            @Param("warehouse_id") Integer warehouseId,
            @Param("created_by") Integer createdBy,
            @Param("warehouse_name") String warehouseName
    );

    @Procedure(name = "DeleteWarehouse")
    Integer deleteWarehouses(@Param("warehouse_ids") String warehouseIds);
}
