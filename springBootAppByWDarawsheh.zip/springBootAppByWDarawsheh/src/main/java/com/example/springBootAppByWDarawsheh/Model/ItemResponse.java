package com.example.springBootAppByWDarawsheh.Model;

public class ItemResponse {
    private Integer id;

    public ItemResponse(Integer id) {
        this.id = id;
    }

    // Getter and Setter
    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }
}
