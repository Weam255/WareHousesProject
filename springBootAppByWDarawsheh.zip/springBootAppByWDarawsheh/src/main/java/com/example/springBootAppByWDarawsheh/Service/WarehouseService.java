package com.example.springBootAppByWDarawsheh.Service;

import com.example.springBootAppByWDarawsheh.Model.Warehouse;
import com.example.springBootAppByWDarawsheh.Model.WarehouseResponse;
import com.example.springBootAppByWDarawsheh.Repository.WarehouseRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.util.List;

@Service
public class WarehouseService {
    @Autowired
    private WarehouseRepository warehouseRepository;

    @Transactional
    public List<Warehouse> getWarehouses(Integer wId, Integer wCreatedBy, String wName) {
        try {
        return warehouseRepository.returnWarehouses(wId, wCreatedBy, wName);
        } catch (Exception e) {
            // Log the exception (optional)
            System.out.println("An error occurred during login: " + e.getMessage());
            return null; // or handle the exception as needed
        }
    }

        public WarehouseResponse insertWarehouse(String wName, String wDescription, String wCreatedBy) {
            try {
                Integer generatedId = warehouseRepository.insertWarehouse(wName, wDescription, wCreatedBy);
                return new WarehouseResponse(generatedId);
            } catch (Exception e) {
                System.out.println("An error occurred while adding the warehouse: " + e.getMessage());
                // Return a response or throw a custom exception if needed
                return null;
            }
        }


    public Integer deleteWarehouses(String warehouseIds) {
        return warehouseRepository.deleteWarehouses(warehouseIds);
    }
}
