package com.example.springBootAppByWDarawsheh.Controller;

import com.example.springBootAppByWDarawsheh.Model.Warehouse;
import com.example.springBootAppByWDarawsheh.Model.WarehouseResponse;
import com.example.springBootAppByWDarawsheh.Service.WarehouseService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/api/warehouses")
public class WarehouseController {
    @Autowired
    private WarehouseService warehouseService;

    @PostMapping("/getWarehouses")
    public ResponseEntity<List<Warehouse>> getWarehouses() {
        List<Warehouse> warehouses = warehouseService.getWarehouses(null, null, null);
        return ResponseEntity.ok(warehouses);
    }



        @PostMapping("/addWarehouse")
        public ResponseEntity<WarehouseResponse> insertWarehouse(@RequestBody Warehouse warehouse) {
            WarehouseResponse response = warehouseService.insertWarehouse(
                    warehouse.getWarehouseName(),
                    warehouse.getWarehouseDescription(),
                    warehouse.getCreatedBy()
            );

            if (response != null) {
                return ResponseEntity.ok(response);
            } else {
                return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                        .body(new WarehouseResponse("Failed to add the warehouse"));
            }
        }


    @DeleteMapping("/deleteWarehouse")
    public ResponseEntity<String> deleteWarehouses(@RequestBody String warehouseIds) {
        try {
            warehouseService.deleteWarehouses(warehouseIds);
            return ResponseEntity.ok("Warehouses deleted successfully.");
        } catch (DataAccessException e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error deleting warehouses: " + e.getMessage());
        }
    }
}
